####Function create a grid of x*y (x=col,y=row)
library(plotrix)
col=20
row=20

#create the dataframe of all the sites with their coordinate
XCOORDm <- rep(1:col, times = row)
YCOORDm <- rep(1:row, each = col)
COORDm <- as.data.frame(cbind(XCOORDm, YCOORDm)) #coordinate of all the pixels (x,y)

#create the grid
grid <- t(matrix((1:(col * row)), ncol = col))

#Generate the palette for the matrix and the legend.  Generate labels for the legend
palmat <- color.scale(grid, 1, 1, 1)
palleg <- color.gradient(1, 1, 1, nslices=100)

#Set up the plot area and plot the matrix
par(mar=c(5, 5, 5, 8))
color2D.matplot(grid, cellcolors=palmat, main=paste(col, " X ", row, " patches landscape", sep=""), show.values=2, vcol=rgb(0,0,0), axes=FALSE, vcex=0.7)

#add axis x
axis(1, at=seq(1, col, 1)-0.5, labels=seq(1, col, 1), tck=-0.01, padj=-1)

#In the axis() statement below, note that the labels are decreasing.  This is because
#the above color2D.matplot() statement has "axes=FALSE" and a normal axis()
#statement was used.
axis(2, at=seq(1, row, 1)-0.5, labels=seq(row, 1, -1), tck=-0.01, padj=0.7)





#find the centre of the grid
if (col %% 2 == 0) {    #return the 2 centre pixel
  xcent <- c(col / 2, col / 2 + 1)
} else{  #return the centre pixel
  xcent <- (col + 1) / 2
}

if (row %% 2 == 0) {
  ycent <- c(row / 2, row / 2 + 1)
} else{
  ycent <- (row + 1) / 2
}

#grid centre can be 1 centre pixel (x%2=1, y%2=1); 2 pixel(x%2=1,y%2=0 or x%2=1,y%2=0); 4 pixel(x%2=0,y%2=0)
gridcent <- NULL
for (i in 1:length(xcent)) {
  for (j in 1:length(ycent)) {
    gridcent <- c(gridcent, grid[xcent[i], ycent[j]])
  }
}
gridcent


