#####Fonction cree une courbe sinous de K#######


kSin<-function(cycleTime,totalCycle,kMax){

  #total runtime
  runtime<-cycleTime*totalCycle
  runtime

  #all the time stpes
  timeSteps<-c(0:runtime)
  timeSteps

  #sine curve in a cycle time  
  sinCurve<-sin(2*pi*timeSteps/cycleTime)

  #K curve
  kSin<- round ((sinCurve+1)/2*kMax)

  #
  picSteps<- c(0:(totalCycle-1)*cycleTime) + ceiling(cycleTime/4)+ 1
  kSin[picSteps]<-kMax
  
  valSteps<- c(0:(totalCycle-1)*cycleTime) + ceiling(cycleTime*3/4)+1
  kSin[valSteps]<-0

  plot(timeSteps,kSin, type="o",col="blue", lwd=3, main=paste("title"))

  return(kSin)
}


####test function####
kSin(48,10,60)
kSin(24,10,60)
kSin(12,10,60)



