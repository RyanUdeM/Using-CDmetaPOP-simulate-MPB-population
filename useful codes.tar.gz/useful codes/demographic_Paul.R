####This script is written by Ryan for his 2017 summer internship in Labjames#####
####this function is based on Paul's demographics function, and show's the occupation of the population on the landscape
demographics<-function(directory,col,row,ind){
  setwd(directory)
  dir.create("Demographics")
  path<-paste(directory,"Demographics",sep="/")
  summary_pop<-read.table("summary_popAllTime.csv",sep=",",header=TRUE)
  summary<-summary_pop[,c(1,4)]
  popu<-summary[-seq(2,nrow(summary),2),,drop=FALSE]
  write.table(popu[,2],file="indivs.csv",sep=",",quote=FALSE,row.names=FALSE,col.names=FALSE)
  pop<-read.table("indivs.csv",sep="|")
  data<-cbind(popu[,1],pop[,2:(ncol(pop)-1)])
  setwd(path)
  rbPal<-colorRampPalette(c('yellow','red'))
  colors<-rbPal(ceiling(ind*3.33))
  for(i in 1:nrow(data)){
    demo<-data[i,]
    name<-paste("Generation",i,"png",sep=".")
    png(filename=name)
    par(mai=c(1.0,1.0,0,0),oma=c(1,1,1,1),cex.main=1.5)
    plot(0,xlim=c(1,col),ylim=c(1,row),type="n",ann=FALSE)
    rect(xleft=(row-1)/2, ybottom=(col-1)/2, xright=((row+1)/2+1), ytop=((col+1)/2+1), density = NULL, angle = 90,
         col = NA, border = NULL, lty = par("lty"), lwd = par("lwd"))
    title<-paste("Time step",(i*2),sep=" ")
    mtext(title,side=2,line=5)
    for(c in 1:(ncol(demo)-1)){
      if(demo[1+c]=="0"){
        value<-0
      }else if(demo[1+c]!="0"){
        value<-as.numeric(demo[1+c])
        colour<-colors[value]
        y<-floor((c/col)+1)
        x<-(((c/col)-(y-1))*col)
        points(x,y,pch=22,col=colour,bg=colour,cex=3)
      }
    }
    dev.off()
  }
}