#####################################
#importer les pairwise Fst de 40 ans
directory<-"F:/Ryan(simulations)/simulation_grid_nolimit/40y_nolimit/40y_81x81_3x3_dis899_k30/metadat"
setwd(directory)

load("FstP_Mean_pks_40y899.RData")


directory<-"F:/Ryan(simulations)/simulation_grid_nolimit/40y_nolimit/40y_51x51_3x3_dis299_k30/metadat"
setwd(directory)

load("FstP_Mean_pks_40y299.RData")


directory<-"F:/Ryan(simulations)/simulation_grid_nolimit/40y_nolimit/40y_41x41_3x3_dis199_k30/metadat"
setwd(directory)

load("FstP_Mean_pks_40y199.RData")

####################################
#importer les pairwise Fst de 20 ans
directory<-"F:/Ryan(simulations)/simulation_grid_nolimit/20y_nolimit/20y_61x61_3x3_dis899_k30/metadat"
setwd(directory)

load("FstP_Mean_pks_20y899.RData")


directory<-"F:/Ryan(simulations)/simulation_grid_nolimit/20y_nolimit/20y_31x31_3x3_dis299_k30/metadat"
setwd(directory)

load("FstP_Mean_pks_20y299.RData")


directory<-"F:/Ryan(simulations)/simulation_grid_nolimit/20y_nolimit/20y_21x21_3x3_dis199_k30/metadat"
setwd(directory)

load("FstP_Mean_pks_20y199.RData")

####################################
#importer les pairwise Fst de 10 ans
directory<-"F:/Ryan(simulations)/simulation_grid_nolimit/10y_nolimit/10y_41x41_3x3_dis899_k30/metadat"
setwd(directory)

load("FstP_Mean_pks_10y899.RData")


directory<-"F:/Ryan(simulations)/simulation_grid_nolimit/10y_nolimit/10y_21x21_3x3_dis299_k30/metadat"
setwd(directory)

load("FstP_Mean_pks_10y299.RData")


directory<-"F:/Ryan(simulations)/simulation_grid_nolimit/10y_nolimit/10y_21x21_3x3_dis199_k30/metadat"
setwd(directory)

load("FstP_Mean_pks_10y199.RData")

#find the biggest Fst value of all the matrix
MaxFstOfAll<-max(FstP_Mean_pks_10y199,FstP_Mean_pks_10y299,FstP_Mean_pks_10y899,
            FstP_Mean_pks_20y199,FstP_Mean_pks_20y299,FstP_Mean_pks_20y899,
            FstP_Mean_pks_40y199,FstP_Mean_pks_40y299,FstP_Mean_pks_40y899)


FstList<-list(FstP_Mean_pks_10y199,FstP_Mean_pks_10y299,FstP_Mean_pks_10y899,
           FstP_Mean_pks_20y199,FstP_Mean_pks_20y299,FstP_Mean_pks_20y899,
           FstP_Mean_pks_40y199,FstP_Mean_pks_40y299,FstP_Mean_pks_40y899)

panel<-matrix(c(1:9),nrow=3,ncol=3,byrow=TRUE)
panel<-rbind(panel,c(10,0,0))

layout(panel, widths=c(3,3,3,1),heights=c(2,2,2,0.2))
#par(mfrow=c(3,3))

for(i in 1:9){

#####################################################
##########plot heatmaps##############################
#####################################################
mean_FstP<-FstList[[i]]


##plot pairwise Fst (Heat map)

numericMatrix<-as.matrix(mean_FstP)

numericMatrix[upper.tri(numericMatrix)]<-0

# preliminar functions
#----Mirror matrix (left-right)----
mirror.matrix <- function(x) {
  xx <- as.data.frame(x);
  xx <- rev(xx);
  xx <- as.matrix(xx);
  xx;
}

#----Rotate matrix 270 clockworks----
rotate270.matrix <- function(x) {
  mirror.matrix(t(x))
}

Matrix <- rotate270.matrix(numericMatrix)



ColorRamp <- colorRampPalette(c("white", "red", "yellow"))

timewithspaces= Sys.time()
timeAttr= gsub(pattern = " ",replacement = "_",x =  timewithspaces)
##outfileGraphic <- paste("pairFstMatrix", ".png", sep="")
# outfileGraphic <- paste(outfile, "pairFstMatrix ", timeAttr, ".pdf", sep="")

#save graphic
#png(outfileGraphic)
# pdf(outfileGraphic, width = 10, height = 10)  


smallplot <- c(0.874, 0.9, 0.18, 0.83)
bigplot <- c(0.13, 0.85, 0.14, 0.87)

old.par <- par(no.readonly = TRUE)

# draw legend --------------------------------
par(plt = smallplot)

# get legend values
Min <- min(Matrix, na.rm=TRUE)
Max <- max(MaxFstOfAll, na.rm=TRUE)
binwidth <- (Max - Min) / 64
y <- seq(Min + binwidth/2, Max - binwidth/2, by = binwidth)
z <- matrix(y, nrow = 1, ncol = length(y))

image(1, y, z, col = ColorRamp(64),xlab="", ylab="", axes=FALSE)

# adjust axis if only one value exists
if(Min == Max){
  axis(side=4, las = 2, cex.axis=0.8, at=Min, labels=round(Min, 2))
} else {
  axis(side=4, las = 2, cex.axis=0.8)
}

box()
mtext(text=expression(bold()), side=4, line=2.5, cex=1.1)

#draw main graphic ---------------------------
a <- ncol(numericMatrix)
b <- nrow(numericMatrix)

x <- c(1:a)
y <- c(1:b)

par(new = TRUE, plt = bigplot)

#max Fst in the matrix

max<-max(mean_FstP)
colors<-max/MaxFstOfAll*64

image(x,y,as.matrix(Matrix), col=ColorRamp(64)[0:colors],
      main=expression(), xlab="",
      ylab="", axes=FALSE)
box()

#add labels
Labels<-c(1:10)
if(is.null(Labels)){
  axis(1, at = c(1:a))
  axis(2, at = c(1:b), labels=c(b:1))
  mtext(side = 1, at =(a/2), line = 2.5, text = "Population", cex=1,
        font=2)
  mtext(side = 2, at =(b/2), line = 2.7, text = "Population", cex=1,
        font=2)
} else{
  axis(1, at = c(1:a), labels=Labels[1:length(Labels)], cex.axis=0.75,
       las=2)
  axis(2, at = c(1:b), labels=Labels[length(Labels):1], cex.axis=0.75,
       las=2)
}


#par(old.par)  #reset graphic parameters

#dev.off()
}

#plot color label

# get legend values
Min <- 0
Max <- MaxFstOfAll
binwidth <- (Max - Min) / 64
y <- seq(Min + binwidth/2, Max - binwidth/2, by = binwidth)
z <- matrix(y, ncol = 1, nrow = length(y))

image(y, 1, z, col = ColorRamp(64),xlab="", ylab="", axes=FALSE)

# adjust axis if only one value exists
if(Min == Max){
  axis(side=1, las = 2, cex.axis=0.8, at=Min, labels=round(Min, 2))
} else {
  axis(side=1, las = 2, cex.axis=0.8)
}

box()
mtext(text=expression(bold()), side=4, line=2.5, cex=1.1)
